import{p as s}from"./B3_v5Jja.js";const g=s("/assets/images/blog/blog1.jpg"),t=s("/assets/images/blog/blog2.jpg"),a=s("/assets/images/blog/blog3.jpg");export{g as _,t as a,a as b};
