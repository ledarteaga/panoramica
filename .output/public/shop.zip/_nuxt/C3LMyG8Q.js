import{p as s}from"./B3_v5Jja.js";const o=s("/assets/images/hero/title-arrow.png");export{o as _};
