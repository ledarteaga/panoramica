import{p as s}from"./B3_v5Jja.js";const e=s("/assets/images/about/circle-text.svg");export{e as _};
