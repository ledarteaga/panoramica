import{p as s}from"./B3_v5Jja.js";const t=s("/assets/images/blog/blog-author1.jpg"),a=s("/assets/images/blog/blog-author2.jpg"),g=s("/assets/images/blog/blog-author3.jpg");export{t as _,a,g as b};
