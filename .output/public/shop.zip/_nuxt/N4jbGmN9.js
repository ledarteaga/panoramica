import{p as s}from"./B3_v5Jja.js";const e=s("/assets/images/team/skill-left.png");export{e as _};
