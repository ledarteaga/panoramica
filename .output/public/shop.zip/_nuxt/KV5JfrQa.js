import{p as s}from"./B3_v5Jja.js";const t=s("/assets/images/services/web-design-text.svg");export{t as _};
