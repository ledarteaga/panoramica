import{p as s}from"./B3_v5Jja.js";const o=s("/assets/images/about/about-three.jpg");export{o as _};
